from google import genai

# ComicCraft - AI Comic Story Creator using Gemini Models
# Install: pip install -r requirements.txt
# Replace YOUR_GEMINI_API_KEY with your Gemini API key.

API_KEY = "YOUR_GEMINI_API_KEY"
client = genai.Client(api_key=API_KEY)


def create_comic():
    print("=" * 55)
    print("              COMICCRAFT")
    print("   AI Comic Story Creator using Gemini Models")
    print("=" * 55)

    idea = input("\nEnter your comic story idea: ").strip()

    if not idea:
        print("Please enter a story idea.")
        return

    try:
        panels = int(input("Enter number of panels (2-10): "))
        if panels < 2 or panels > 10:
            print("Please choose between 2 and 10 panels.")
            return
    except ValueError:
        print("Please enter a valid number.")
        return

    prompt = f"""
You are ComicCraft, an AI comic story creator.

Create a creative comic story based on this idea:
{idea}

Create exactly {panels} comic panels.

First provide:
TITLE:
CHARACTERS:
- Character name: short description

Then provide every panel in this format:

PANEL 1:
Scene:
Characters:
Dialogue:
Narration:

Continue until PANEL {panels}.

Use simple English and make the story interesting and suitable for students.
"""

    print("\nGenerating your comic...\n")

    try:
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )

        print("=" * 55)
        print("                    YOUR COMIC")
        print("=" * 55)
        print(response.text)

        save = input("\nSave this comic to a text file? (y/n): ").strip().lower()
        if save == "y":
            with open("comic_story.txt", "w", encoding="utf-8") as file:
                file.write(response.text)
            print("Comic saved as comic_story.txt")

    except Exception as error:
        print("\nError while generating the comic:")
        print(error)


if __name__ == "__main__":
    create_comic()
