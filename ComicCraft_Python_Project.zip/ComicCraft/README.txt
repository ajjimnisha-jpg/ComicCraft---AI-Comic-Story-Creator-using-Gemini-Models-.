COMICCRAFT - AI Comic Story Creator using Gemini Models

1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Install the required library:
   pip install -r requirements.txt
4. Open app.py.
5. Replace YOUR_GEMINI_API_KEY with your Gemini API key.
6. Run:
   python app.py

The program asks for a story idea and number of panels, then uses Gemini
to generate the comic title, characters, scenes, dialogue and narration.
